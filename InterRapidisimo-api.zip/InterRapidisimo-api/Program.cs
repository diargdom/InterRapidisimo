using InterRapidisimo_api.Services;
using InterRapidisimo_api.WebApp;

var builder = WebApplication.CreateBuilder(args);
//Configuraci�n de servicios en el contenedor de inyecci�n de dependencias (DI)
builder.Services.AddServicesGeneral(builder.Configuration);

var app = builder.Build();
app.ConfigureApplication();

app.Run();
